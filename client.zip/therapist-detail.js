(function () {
  const API_ME = "/server/agency_api/api/me";
  const API_THERAPISTS = "/server/agency_api/api/therapists";
  const API_SEND_CREDENTIALS = "/server/agency_api/api/therapists/send-credentials";
  const PAGE_SIZE = 50;

  const tableLoading = document.getElementById("table-loading");
  const tableError = document.getElementById("table-error");
  const tableEmpty = document.getElementById("table-empty");
  const tableWrapper = document.getElementById("table-wrapper");
  const tbody = document.getElementById("therapist-tbody");
  const errorMessage = document.getElementById("error-message");

  const statTotal = document.getElementById("stat-total");
  const statPt = document.getElementById("stat-pt");
  const statOt = document.getElementById("stat-ot");
  const statSt = document.getElementById("stat-st");

  const searchInput = document.getElementById("search-input");
  const disciplineFilter = document.getElementById("discipline-filter");
  const refreshBtn = document.getElementById("refresh-btn");
  const retryBtn = document.getElementById("retry-btn");

  // Selection & Action elements
  const sendCredentialsBtn = document.getElementById("send-credentials-btn");
  const selectedBadge = document.getElementById("selected-badge");
  const selectAllCheckbox = document.getElementById("select-all-therapists");
  const actionAlert = document.getElementById("action-alert");
  const actionAlertText = document.getElementById("action-alert-text");
  const actionAlertClose = document.getElementById("action-alert-close");

  // Pagination elements
  const paginationContainer = document.getElementById("pagination-container");
  const pageStart = document.getElementById("page-start");
  const pageEnd = document.getElementById("page-end");
  const pageTotalCount = document.getElementById("page-total-count");
  const paginationPages = document.getElementById("pagination-pages");
  const firstPageBtn = document.getElementById("first-page-btn");
  const prevPageBtn = document.getElementById("prev-page-btn");
  const nextPageBtn = document.getElementById("next-page-btn");
  const lastPageBtn = document.getElementById("last-page-btn");

  let allTherapists = [];
  let currentFiltered = [];
  let currentPage = 1;
  const selectedTherapistIds = new Set();
  let alertTimer = null;

  function escapeHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function showAlert(type, message) {
    if (!actionAlert || !actionAlertText) return;
    if (alertTimer) clearTimeout(alertTimer);

    actionAlert.className = `action-alert ${
      type === "success" ? "action-alert-success" : "action-alert-error"
    }`;
    actionAlertText.textContent = message;
    actionAlert.hidden = false;

    if (type === "success") {
      alertTimer = setTimeout(() => {
        actionAlert.hidden = true;
      }, 7000);
    }
  }

  function hideAlert() {
    if (actionAlert) actionAlert.hidden = true;
    if (alertTimer) clearTimeout(alertTimer);
  }

  function getDisciplineClass(disc) {
    const d = (disc || "").toUpperCase();
    if (d.includes("PT") || d.includes("PTA")) return "disc-badge disc-pt";
    if (d.includes("OT") || d.includes("COTA")) return "disc-badge disc-ot";
    if (d.includes("ST") || d.includes("SLP")) return "disc-badge disc-st";
    if (d.includes("MSW") || d.includes("SOCIAL")) return "disc-badge disc-msw";
    return "disc-badge";
  }

  function getStatusClass(status) {
    const s = (status || "").toLowerCase();
    if (s === "active" || s === "approved") return "status-badge badge-active";
    if (s.includes("onboard") || s === "pending") return "status-badge badge-pending";
    if (s === "inactive" || s === "terminated") return "status-badge badge-danger";
    return "status-badge badge-default";
  }

  function getCurrentPageTherapists() {
    const startIndex = (currentPage - 1) * PAGE_SIZE;
    return currentFiltered.slice(startIndex, startIndex + PAGE_SIZE);
  }

  function updateSelectionUI() {
    const totalSelected = selectedTherapistIds.size;

    // Update Send Credentials button & badge
    if (selectedBadge) {
      selectedBadge.textContent = totalSelected;
      selectedBadge.hidden = totalSelected === 0;
    }

    if (sendCredentialsBtn) {
      sendCredentialsBtn.disabled = totalSelected === 0;
      sendCredentialsBtn.title =
        totalSelected > 0
          ? `Send credentials for ${totalSelected} selected therapist${totalSelected === 1 ? "" : "s"}`
          : "Select therapists from the list to send credentials";
    }

    // Update row highlighting and checkboxes
    if (tbody) {
      const rows = tbody.querySelectorAll("tr");
      rows.forEach((row) => {
        const checkbox = row.querySelector(".therapist-row-checkbox");
        if (checkbox) {
          const id = checkbox.getAttribute("data-id");
          const isSelected = selectedTherapistIds.has(id);
          checkbox.checked = isSelected;
          row.classList.toggle("row-selected", isSelected);
        }
      });
    }

    // Update Select All checkbox state for current page
    if (selectAllCheckbox) {
      const pageTherapists = getCurrentPageTherapists();
      if (pageTherapists.length === 0) {
        selectAllCheckbox.checked = false;
        selectAllCheckbox.indeterminate = false;
      } else {
        const selectedOnPage = pageTherapists.filter((t) =>
          selectedTherapistIds.has(t.id)
        ).length;

        if (selectedOnPage === pageTherapists.length) {
          selectAllCheckbox.checked = true;
          selectAllCheckbox.indeterminate = false;
        } else if (selectedOnPage > 0) {
          selectAllCheckbox.checked = false;
          selectAllCheckbox.indeterminate = true;
        } else {
          selectAllCheckbox.checked = false;
          selectAllCheckbox.indeterminate = false;
        }
      }
    }
  }

  function renderTableRows(list) {
    if (!tbody) return;
    tbody.innerHTML = list
      .map((t) => {
        const discClass = getDisciplineClass(t.discipline);
        const statusClass = getStatusClass(t.status);
        const isSelected = selectedTherapistIds.has(t.id);
        const cityStateZip = [
          t.city !== "—" ? t.city : "",
          t.state !== "—" ? t.state : "",
          t.zip !== "—" ? t.zip : "",
        ]
          .filter(Boolean)
          .join(", ") || "—";

        const emailLink = t.email && t.email !== "—"
          ? `<a class="text-link" href="mailto:${escapeHtml(t.email)}">${escapeHtml(t.email)}</a>`
          : `<span class="text-muted">—</span>`;

        const phoneLink = t.phone && t.phone !== "—"
          ? `<a class="phone-link" href="tel:${escapeHtml(t.phone)}">${escapeHtml(t.phone)}</a>`
          : `<span class="text-muted">—</span>`;

        return `
          <tr class="${isSelected ? "row-selected" : ""}">
            <td class="td-checkbox">
              <input
                type="checkbox"
                class="custom-checkbox therapist-row-checkbox"
                data-id="${escapeHtml(t.id)}"
                aria-label="Select ${escapeHtml(t.name)}"
                ${isSelected ? "checked" : ""}
              />
            </td>
            <td>
              <div class="patient-name-cell">
                <div class="patient-avatar">${escapeHtml(t.name.charAt(0).toUpperCase())}</div>
                <div>
                  <div class="patient-name">${escapeHtml(t.name)}</div>
                </div>
              </div>
            </td>
            <td>
              <span class="${discClass}">${escapeHtml(t.discipline)}</span>
            </td>
            <td>
              ${emailLink}
            </td>
            <td>
              ${phoneLink}
            </td>
            <td>
              <div><strong>${escapeHtml(cityStateZip)}</strong></div>
            </td>
            <td class="address-cell">
              <span>${escapeHtml(t.address)}</span>
            </td>
            <td>
              <span class="${statusClass}">${escapeHtml(t.status || t.layout || "Active")}</span>
            </td>
          </tr>
        `;
      })
      .join("");

    // Attach row checkbox event listeners
    tbody.querySelectorAll(".therapist-row-checkbox").forEach((cb) => {
      cb.addEventListener("change", (e) => {
        const id = e.target.getAttribute("data-id");
        if (e.target.checked) {
          selectedTherapistIds.add(id);
        } else {
          selectedTherapistIds.delete(id);
        }
        updateSelectionUI();
      });
    });

    updateSelectionUI();
  }

  function renderPagination(totalItems) {
    if (!paginationContainer) return;

    if (totalItems === 0) {
      paginationContainer.hidden = true;
      return;
    }

    paginationContainer.hidden = false;
    const totalPages = Math.max(1, Math.ceil(totalItems / PAGE_SIZE));

    if (currentPage > totalPages) {
      currentPage = totalPages;
    } else if (currentPage < 1) {
      currentPage = 1;
    }

    const start = (currentPage - 1) * PAGE_SIZE + 1;
    const end = Math.min(currentPage * PAGE_SIZE, totalItems);

    if (pageStart) pageStart.textContent = start;
    if (pageEnd) pageEnd.textContent = end;
    if (pageTotalCount) pageTotalCount.textContent = totalItems;

    if (firstPageBtn) firstPageBtn.disabled = currentPage === 1;
    if (prevPageBtn) prevPageBtn.disabled = currentPage === 1;
    if (nextPageBtn) nextPageBtn.disabled = currentPage === totalPages;
    if (lastPageBtn) lastPageBtn.disabled = currentPage === totalPages;

    if (paginationPages) {
      paginationPages.innerHTML = "";
      const pageNumbers = getPaginationPages(currentPage, totalPages);

      pageNumbers.forEach((item) => {
        if (item === "...") {
          const ellipsis = document.createElement("span");
          ellipsis.className = "pagination-ellipsis";
          ellipsis.textContent = "…";
          paginationPages.appendChild(ellipsis);
        } else {
          const btn = document.createElement("button");
          btn.type = "button";
          btn.className = `pagination-btn ${item === currentPage ? "active" : ""}`;
          btn.textContent = item;
          btn.setAttribute("aria-label", `Page ${item}`);
          btn.addEventListener("click", () => goToPage(item));
          paginationPages.appendChild(btn);
        }
      });
    }
  }

  function getPaginationPages(current, total) {
    if (total <= 7) {
      return Array.from({ length: total }, (_, i) => i + 1);
    }

    const pages = [];
    pages.push(1);

    if (current > 3) {
      pages.push("...");
    }

    const start = Math.max(2, current - 1);
    const end = Math.min(total - 1, current + 1);

    for (let i = start; i <= end; i++) {
      pages.push(i);
    }

    if (current < total - 2) {
      pages.push("...");
    }

    pages.push(total);
    return pages;
  }

  function goToPage(page) {
    const totalPages = Math.max(1, Math.ceil(currentFiltered.length / PAGE_SIZE));
    if (page < 1 || page > totalPages || page === currentPage) return;
    currentPage = page;
    renderCurrentPage();

    if (tableWrapper) {
      tableWrapper.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  }

  function renderCurrentPage() {
    if (!tableWrapper || !tbody) return;

    if (!currentFiltered || currentFiltered.length === 0) {
      tableWrapper.hidden = true;
      if (paginationContainer) paginationContainer.hidden = true;
      if (tableEmpty) tableEmpty.hidden = false;
      updateSelectionUI();
      return;
    }

    if (tableEmpty) tableEmpty.hidden = true;
    tableWrapper.hidden = false;

    const pageTherapists = getCurrentPageTherapists();
    renderTableRows(pageTherapists);
    renderPagination(currentFiltered.length);
  }

  function updateStats(list) {
    if (statTotal) statTotal.textContent = list.length;

    const ptCount = list.filter((t) => {
      const d = (t.discipline || "").toUpperCase();
      return d.includes("PT") || d.includes("PTA");
    }).length;
    if (statPt) statPt.textContent = ptCount;

    const otCount = list.filter((t) => {
      const d = (t.discipline || "").toUpperCase();
      return d.includes("OT") || d.includes("COTA");
    }).length;
    if (statOt) statOt.textContent = otCount;

    const stCount = list.filter((t) => {
      const d = (t.discipline || "").toUpperCase();
      return d.includes("ST") || d.includes("SLP");
    }).length;
    if (statSt) statSt.textContent = stCount;
  }

  function applyFilters() {
    const query = searchInput ? searchInput.value.trim().toLowerCase() : "";
    const selectedDisc = disciplineFilter ? disciplineFilter.value.toUpperCase() : "ALL";

    currentFiltered = allTherapists.filter((t) => {
      const disc = (t.discipline || "").toUpperCase();
      const matchesDisc =
        selectedDisc === "ALL" ||
        disc === selectedDisc ||
        (selectedDisc === "ST" && (disc.includes("ST") || disc.includes("SLP"))) ||
        (selectedDisc === "PT" && disc === "PT") ||
        (selectedDisc === "PTA" && disc === "PTA") ||
        (selectedDisc === "OT" && disc === "OT") ||
        (selectedDisc === "COTA" && disc === "COTA") ||
        (selectedDisc === "MSW" && (disc.includes("MSW") || disc.includes("SOCIAL")));

      const matchesQuery =
        !query ||
        t.name?.toLowerCase().includes(query) ||
        t.email?.toLowerCase().includes(query) ||
        t.phone?.toLowerCase().includes(query) ||
        t.city?.toLowerCase().includes(query) ||
        t.state?.toLowerCase().includes(query) ||
        t.zip?.toLowerCase().includes(query) ||
        t.address?.toLowerCase().includes(query) ||
        t.discipline?.toLowerCase().includes(query) ||
        t.id?.toLowerCase().includes(query);

      return matchesDisc && matchesQuery;
    });

    currentPage = 1;
    renderCurrentPage();
  }

  async function loadAgencyInfo() {
    try {
      const res = await fetch(API_ME, { credentials: "include" });
      if (res.status === 401 || res.status === 403) {
        window.location.href = "index.html?error=" + encodeURIComponent("Please sign in to continue");
        return;
      }
    } catch (e) {
      console.warn("Failed to load agency session", e);
    }
  }

  async function loadTherapists() {
    if (tableLoading) tableLoading.hidden = false;
    if (tableError) tableError.hidden = true;
    if (tableEmpty) tableEmpty.hidden = true;
    if (tableWrapper) tableWrapper.hidden = true;
    if (paginationContainer) paginationContainer.hidden = true;

    if (refreshBtn) {
      refreshBtn.classList.add("loading");
    }

    try {
      const response = await fetch(API_THERAPISTS, {
        credentials: "include",
        headers: { Accept: "application/json" },
      });

      if (response.status === 401 || response.status === 403) {
        window.location.href = "index.html?error=" + encodeURIComponent("Please sign in to continue");
        return;
      }

      if (!response.ok) {
        const payload = await response.json().catch(() => ({}));
        throw new Error(payload.message || "Unable to load therapist records");
      }

      const data = await response.json();
      allTherapists = data.therapists || [];

      updateStats(allTherapists);
      applyFilters();
    } catch (err) {
      if (tableError) tableError.hidden = false;
      if (errorMessage) errorMessage.textContent = err.message || "Failed to load therapist records";
    } finally {
      if (tableLoading) tableLoading.hidden = true;
      if (refreshBtn) {
        refreshBtn.classList.remove("loading");
      }
    }
  }

  async function handleSendCredentials() {
    if (selectedTherapistIds.size === 0) {
      showAlert("error", "Please select at least one therapist to send credentials.");
      return;
    }

    const therapistIds = Array.from(selectedTherapistIds);
    const count = therapistIds.length;

    if (sendCredentialsBtn) {
      sendCredentialsBtn.disabled = true;
      const btnSpan = sendCredentialsBtn.querySelector("span");
      if (btnSpan) btnSpan.textContent = "Sending…";
    }

    hideAlert();

    try {
      const res = await fetch(API_SEND_CREDENTIALS, {
        method: "POST",
        credentials: "include",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ therapistIds }),
      });

      const payload = await res.json().catch(() => ({}));

      if (res.status === 401 || res.status === 403) {
        window.location.href = "index.html?error=" + encodeURIComponent("Please sign in to continue");
        return;
      }

      if (!res.ok) {
        const errorMsg =
          payload.message ||
          (payload.details && typeof payload.details === "object"
            ? payload.details.message || JSON.stringify(payload.details)
            : null) ||
          `Server returned error status ${res.status}`;
        throw new Error(errorMsg);
      }

      showAlert(
        "success",
        payload.message || `Credentials request successfully sent for ${count} therapist${count === 1 ? "" : "s"}.`
      );

      // Clear selection after successful transmission
      selectedTherapistIds.clear();
      updateSelectionUI();
    } catch (err) {
      showAlert("error", err.message || "An error occurred while sending credentials.");
    } finally {
      if (sendCredentialsBtn) {
        const btnSpan = sendCredentialsBtn.querySelector("span");
        if (btnSpan) btnSpan.textContent = "Send Credentials";
        updateSelectionUI();
      }
    }
  }

  // Events
  if (searchInput) {
    searchInput.addEventListener("input", applyFilters);
  }

  if (disciplineFilter) {
    disciplineFilter.addEventListener("change", applyFilters);
  }

  if (refreshBtn) {
    refreshBtn.addEventListener("click", loadTherapists);
  }

  if (retryBtn) {
    retryBtn.addEventListener("click", loadTherapists);
  }

  if (sendCredentialsBtn) {
    sendCredentialsBtn.addEventListener("click", handleSendCredentials);
  }

  if (actionAlertClose) {
    actionAlertClose.addEventListener("click", hideAlert);
  }

  // Select All on current page
  if (selectAllCheckbox) {
    selectAllCheckbox.addEventListener("change", (e) => {
      const pageTherapists = getCurrentPageTherapists();
      if (e.target.checked) {
        pageTherapists.forEach((t) => selectedTherapistIds.add(t.id));
      } else {
        pageTherapists.forEach((t) => selectedTherapistIds.delete(t.id));
      }
      updateSelectionUI();
    });
  }

  if (firstPageBtn) {
    firstPageBtn.addEventListener("click", () => goToPage(1));
  }

  if (prevPageBtn) {
    prevPageBtn.addEventListener("click", () => goToPage(currentPage - 1));
  }

  if (nextPageBtn) {
    nextPageBtn.addEventListener("click", () => {
      const totalPages = Math.max(1, Math.ceil(currentFiltered.length / PAGE_SIZE));
      goToPage(currentPage + 1);
    });
  }

  if (lastPageBtn) {
    lastPageBtn.addEventListener("click", () => {
      const totalPages = Math.max(1, Math.ceil(currentFiltered.length / PAGE_SIZE));
      goToPage(totalPages);
    });
  }

  // ==========================================
  // Add Therapist Modal Elements & Logic
  // ==========================================
  const API_AVAILABLE_CONTACTS = "/server/agency_api/api/therapists/available";
  const API_ADD_THERAPISTS = "/server/agency_api/api/therapists/add";
  const MODAL_PAGE_SIZE = 10;

  const openAddModalBtn = document.getElementById("open-add-modal-btn");
  const closeAddModalBtn = document.getElementById("close-add-modal-btn");
  const cancelAddModalBtn = document.getElementById("cancel-add-modal-btn");
  const addTherapistModal = document.getElementById("add-therapist-modal");
  const confirmAddTherapistsBtn = document.getElementById("confirm-add-therapists-btn");
  const modalSearchInput = document.getElementById("modal-search-input");
  const modalSelectionCount = document.getElementById("modal-selection-count");

  const modalAddError = document.getElementById("modal-add-error");
  const modalAddSuccess = document.getElementById("modal-add-success");
  const modalLoadingState = document.getElementById("modal-loading-state");
  const modalEmptyState = document.getElementById("modal-empty-state");
  const modalErrorState = document.getElementById("modal-error-state");
  const modalErrorText = document.getElementById("modal-error-text");
  const modalRetryBtn = document.getElementById("modal-retry-btn");
  const modalTableWrapper = document.getElementById("modal-table-wrapper");
  const modalTbody = document.getElementById("modal-contacts-tbody");
  const selectAllModalCheckbox = document.getElementById("select-all-modal-contacts");

  const modalPaginationContainer = document.getElementById("modal-pagination-container");
  const modalPageStart = document.getElementById("modal-page-start");
  const modalPageEnd = document.getElementById("modal-page-end");
  const modalPageTotal = document.getElementById("modal-page-total");
  const modalPaginationPages = document.getElementById("modal-pagination-pages");
  const modalPrevPageBtn = document.getElementById("modal-prev-page-btn");
  const modalNextPageBtn = document.getElementById("modal-next-page-btn");

  let allAvailableContacts = [];
  let modalFilteredContacts = [];
  let modalCurrentPage = 1;
  const modalSelectedContactIds = new Set();

  function showModalAddError(msg) {
    if (modalAddSuccess) modalAddSuccess.hidden = true;
    if (modalAddError) {
      modalAddError.hidden = false;
      modalAddError.textContent = msg;
    }
  }

  function showModalAddSuccess(msg) {
    if (modalAddError) modalAddError.hidden = true;
    if (modalAddSuccess) {
      modalAddSuccess.hidden = false;
      modalAddSuccess.textContent = msg;
    }
  }

  function clearModalAddBanners() {
    if (modalAddError) modalAddError.hidden = true;
    if (modalAddSuccess) modalAddSuccess.hidden = true;
  }

  function openAddModal() {
    clearModalAddBanners();
    modalSelectedContactIds.clear();
    if (modalSearchInput) modalSearchInput.value = "";
    updateModalSelectionUI();
    if (addTherapistModal) addTherapistModal.hidden = false;
    loadAvailableContacts();
  }

  function closeAddModal() {
    clearModalAddBanners();
    if (addTherapistModal) addTherapistModal.hidden = true;
  }

  function updateModalSelectionUI() {
    const totalSelected = modalSelectedContactIds.size;
    if (modalSelectionCount) {
      modalSelectionCount.innerHTML = `Selected: <strong>${totalSelected}</strong>`;
    }

    if (confirmAddTherapistsBtn) {
      confirmAddTherapistsBtn.disabled = totalSelected === 0;
      const btnSpan = confirmAddTherapistsBtn.querySelector("span");
      if (btnSpan) {
        btnSpan.textContent = totalSelected > 0
          ? `Add Selected Therapist${totalSelected === 1 ? "" : "s"} (${totalSelected})`
          : "Add Selected Therapist";
      }
    }

    // Update row checkboxes & styling
    if (modalTbody) {
      const rows = modalTbody.querySelectorAll("tr");
      rows.forEach((row) => {
        const cb = row.querySelector(".modal-contact-row-checkbox");
        if (cb) {
          const id = cb.getAttribute("data-id");
          const isChecked = modalSelectedContactIds.has(id);
          cb.checked = isChecked;
          row.classList.toggle("row-selected", isChecked);
        }
      });
    }

    // Update select all checkbox for modal current page
    if (selectAllModalCheckbox) {
      const pageContacts = getModalCurrentPageContacts();
      if (pageContacts.length === 0) {
        selectAllModalCheckbox.checked = false;
        selectAllModalCheckbox.indeterminate = false;
      } else {
        const selectedOnPage = pageContacts.filter((c) =>
          modalSelectedContactIds.has(c.id)
        ).length;

        if (selectedOnPage === pageContacts.length) {
          selectAllModalCheckbox.checked = true;
          selectAllModalCheckbox.indeterminate = false;
        } else if (selectedOnPage > 0) {
          selectAllModalCheckbox.checked = false;
          selectAllModalCheckbox.indeterminate = true;
        } else {
          selectAllModalCheckbox.checked = false;
          selectAllModalCheckbox.indeterminate = false;
        }
      }
    }
  }

  function getModalCurrentPageContacts() {
    const start = (modalCurrentPage - 1) * MODAL_PAGE_SIZE;
    return modalFilteredContacts.slice(start, start + MODAL_PAGE_SIZE);
  }

  function renderModalTableRows(list) {
    if (!modalTbody) return;
    modalTbody.innerHTML = list
      .map((c) => {
        const isSelected = modalSelectedContactIds.has(c.id);
        const discClass = getDisciplineClass(c.discipline);
        const statusClass = getStatusClass(c.status);

        return `
          <tr class="${isSelected ? "row-selected" : ""}">
            <td class="td-checkbox">
              <input
                type="checkbox"
                class="custom-checkbox modal-contact-row-checkbox"
                data-id="${escapeHtml(c.id)}"
                aria-label="Select ${escapeHtml(c.name)}"
                ${isSelected ? "checked" : ""}
              />
            </td>
            <td>
              <div class="patient-name-cell">
                <div class="patient-avatar">${escapeHtml((c.name || "T").charAt(0).toUpperCase())}</div>
                <div>
                  <div class="patient-name">${escapeHtml(c.name)}</div>
                </div>
              </div>
            </td>
            <td>
              <span class="${discClass}">${escapeHtml(c.discipline)}</span>
            </td>
            <td>
              <span>${c.email && c.email !== "—" ? escapeHtml(c.email) : "—"}</span>
            </td>
            <td>
              <span>${c.phone && c.phone !== "—" ? escapeHtml(c.phone) : "—"}</span>
            </td>
            <td>
              <span>${c.mobile && c.mobile !== "—" ? escapeHtml(c.mobile) : "—"}</span>
            </td>
            <td>
              <span class="${statusClass}">${escapeHtml(c.status || "Active")}</span>
            </td>
          </tr>
        `;
      })
      .join("");

    modalTbody.querySelectorAll(".modal-contact-row-checkbox").forEach((cb) => {
      cb.addEventListener("change", (e) => {
        const id = e.target.getAttribute("data-id");
        if (e.target.checked) {
          modalSelectedContactIds.add(id);
        } else {
          modalSelectedContactIds.delete(id);
        }
        updateModalSelectionUI();
      });
    });

    updateModalSelectionUI();
  }

  function renderModalPagination(totalItems) {
    if (!modalPaginationContainer) return;
    if (totalItems === 0) {
      modalPaginationContainer.hidden = true;
      return;
    }

    modalPaginationContainer.hidden = false;
    const totalPages = Math.max(1, Math.ceil(totalItems / MODAL_PAGE_SIZE));

    if (modalCurrentPage > totalPages) {
      modalCurrentPage = totalPages;
    } else if (modalCurrentPage < 1) {
      modalCurrentPage = 1;
    }

    const start = (modalCurrentPage - 1) * MODAL_PAGE_SIZE + 1;
    const end = Math.min(modalCurrentPage * MODAL_PAGE_SIZE, totalItems);

    if (modalPageStart) modalPageStart.textContent = start;
    if (modalPageEnd) modalPageEnd.textContent = end;
    if (modalPageTotal) modalPageTotal.textContent = totalItems;

    if (modalPrevPageBtn) modalPrevPageBtn.disabled = modalCurrentPage === 1;
    if (modalNextPageBtn) modalNextPageBtn.disabled = modalCurrentPage === totalPages;

    if (modalPaginationPages) {
      modalPaginationPages.innerHTML = "";
      const pageNumbers = getPaginationPages(modalCurrentPage, totalPages);
      pageNumbers.forEach((item) => {
        if (item === "...") {
          const ellipsis = document.createElement("span");
          ellipsis.className = "pagination-ellipsis";
          ellipsis.textContent = "…";
          modalPaginationPages.appendChild(ellipsis);
        } else {
          const btn = document.createElement("button");
          btn.type = "button";
          btn.className = `pagination-btn ${item === modalCurrentPage ? "active" : ""}`;
          btn.textContent = item;
          btn.setAttribute("aria-label", `Page ${item}`);
          btn.addEventListener("click", () => goModalPage(item));
          modalPaginationPages.appendChild(btn);
        }
      });
    }
  }

  function goModalPage(page) {
    const totalPages = Math.max(1, Math.ceil(modalFilteredContacts.length / MODAL_PAGE_SIZE));
    if (page < 1 || page > totalPages || page === modalCurrentPage) return;
    modalCurrentPage = page;
    renderModalCurrentPage();
  }

  function renderModalCurrentPage() {
    if (!modalTableWrapper || !modalTbody) return;

    if (!modalFilteredContacts || modalFilteredContacts.length === 0) {
      modalTableWrapper.hidden = true;
      if (modalPaginationContainer) modalPaginationContainer.hidden = true;
      if (modalEmptyState) modalEmptyState.hidden = false;
      updateModalSelectionUI();
      return;
    }

    if (modalEmptyState) modalEmptyState.hidden = true;
    modalTableWrapper.hidden = false;

    const pageContacts = getModalCurrentPageContacts();
    renderModalTableRows(pageContacts);
    renderModalPagination(modalFilteredContacts.length);
  }

  function applyModalFilters() {
    const query = modalSearchInput ? modalSearchInput.value.trim().toLowerCase() : "";

    modalFilteredContacts = allAvailableContacts.filter((c) => {
      return (
        !query ||
        c.name?.toLowerCase().includes(query) ||
        c.email?.toLowerCase().includes(query) ||
        c.phone?.toLowerCase().includes(query) ||
        c.mobile?.toLowerCase().includes(query) ||
        c.discipline?.toLowerCase().includes(query) ||
        c.id?.toLowerCase().includes(query)
      );
    });

    modalCurrentPage = 1;
    renderModalCurrentPage();
  }

  async function loadAvailableContacts() {
    if (modalLoadingState) modalLoadingState.hidden = false;
    if (modalErrorState) modalErrorState.hidden = true;
    if (modalEmptyState) modalEmptyState.hidden = true;
    if (modalTableWrapper) modalTableWrapper.hidden = true;
    if (modalPaginationContainer) modalPaginationContainer.hidden = true;

    try {
      const res = await fetch(API_AVAILABLE_CONTACTS, {
        credentials: "include",
        headers: { Accept: "application/json" },
      });

      if (res.status === 401 || res.status === 403) {
        window.location.href = "index.html?error=" + encodeURIComponent("Please sign in to continue");
        return;
      }

      if (!res.ok) {
        const payload = await res.json().catch(() => ({}));
        throw new Error(payload.message || "Failed to load contacts from Zoho CRM");
      }

      const data = await res.json();
      allAvailableContacts = data.contacts || [];

      applyModalFilters();
    } catch (err) {
      if (modalErrorState) modalErrorState.hidden = false;
      if (modalErrorText) modalErrorText.textContent = err.message || "Failed to load contacts from Zoho CRM";
    } finally {
      if (modalLoadingState) modalLoadingState.hidden = true;
    }
  }

  async function handleAddTherapists() {
    if (modalSelectedContactIds.size === 0) {
      showModalAddError("Please select at least one contact to add.");
      return;
    }

    const contactIds = Array.from(modalSelectedContactIds);
    const count = contactIds.length;

    if (confirmAddTherapistsBtn) {
      confirmAddTherapistsBtn.disabled = true;
      const btnSpan = confirmAddTherapistsBtn.querySelector("span");
      if (btnSpan) btnSpan.textContent = "Adding…";
    }

    clearModalAddBanners();

    try {
      const res = await fetch(API_ADD_THERAPISTS, {
        method: "POST",
        credentials: "include",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ contactIds }),
      });

      const payload = await res.json().catch(() => ({}));

      if (res.status === 401 || res.status === 403) {
        window.location.href = "index.html?error=" + encodeURIComponent("Please sign in to continue");
        return;
      }

      if (!res.ok || payload.success === false) {
        throw new Error(payload.message || "Unable to add therapists in Zoho CRM");
      }

      showModalAddSuccess(payload.message || `Successfully added ${count} therapist${count === 1 ? "" : "s"}.`);

      // Automatically close modal after 1.2s and refresh main therapist roster
      setTimeout(() => {
        closeAddModal();
        showAlert("success", payload.message || `Successfully added ${count} therapist${count === 1 ? "" : "s"} to your agency roster.`);
        loadTherapists();
      }, 1200);
    } catch (err) {
      showModalAddError(err.message || "An error occurred while adding therapists.");
    } finally {
      if (confirmAddTherapistsBtn) {
        confirmAddTherapistsBtn.disabled = false;
        const btnSpan = confirmAddTherapistsBtn.querySelector("span");
        if (btnSpan) {
          const totalSelected = modalSelectedContactIds.size;
          btnSpan.textContent = totalSelected > 0
            ? `Add Selected Therapist${totalSelected === 1 ? "" : "s"} (${totalSelected})`
            : "Add Selected Therapist";
        }
      }
    }
  }

  // Modal Events
  if (openAddModalBtn) {
    openAddModalBtn.addEventListener("click", openAddModal);
  }

  if (closeAddModalBtn) {
    closeAddModalBtn.addEventListener("click", closeAddModal);
  }

  if (cancelAddModalBtn) {
    cancelAddModalBtn.addEventListener("click", closeAddModal);
  }

  if (addTherapistModal) {
    addTherapistModal.addEventListener("click", (e) => {
      if (e.target === addTherapistModal) closeAddModal();
    });
  }

  if (modalSearchInput) {
    modalSearchInput.addEventListener("input", applyModalFilters);
  }

  if (modalRetryBtn) {
    modalRetryBtn.addEventListener("click", loadAvailableContacts);
  }

  if (confirmAddTherapistsBtn) {
    confirmAddTherapistsBtn.addEventListener("click", handleAddTherapists);
  }

  if (selectAllModalCheckbox) {
    selectAllModalCheckbox.addEventListener("change", (e) => {
      const pageContacts = getModalCurrentPageContacts();
      if (e.target.checked) {
        pageContacts.forEach((c) => modalSelectedContactIds.add(c.id));
      } else {
        pageContacts.forEach((c) => modalSelectedContactIds.delete(c.id));
      }
      updateModalSelectionUI();
    });
  }

  if (modalPrevPageBtn) {
    modalPrevPageBtn.addEventListener("click", () => goModalPage(modalCurrentPage - 1));
  }

  if (modalNextPageBtn) {
    modalNextPageBtn.addEventListener("click", () => goModalPage(modalCurrentPage + 1));
  }

  // Initialize
  loadAgencyInfo();
  loadTherapists();
})();
